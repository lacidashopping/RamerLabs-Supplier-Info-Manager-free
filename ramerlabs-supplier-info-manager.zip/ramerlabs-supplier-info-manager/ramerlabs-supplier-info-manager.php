<?php
/**
 * Plugin Name: RamerLabs Supplier Info Manager
 * Description: Manage supplier information, product URLs, prices, and contact details with search capability matrices.
 * Version:     1.4.5
 * Author:      ramerlabs.com
 * Author URI:  https://github.com/lacidashopping/RamerLabs-Supplier-Info-Manager-free
 * Text Domain: ramerlabs-supplier-info-manager
 * License:     GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class RamerLabs_Supplier_Manager {

    private $table_name;
    private $page_slug = 'ramerlabs-supplier-info-manager';

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'ramerlabs_supplier_info';

        register_activation_hook( __FILE__, array( $this, 'create_db_table' ) );
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'handle_db_actions' ) );
        add_action( 'admin_head', array( $this, 'inject_custom_styles' ) );
    }

    public function create_db_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $this->table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_name varchar(255) NOT NULL,
            product_url text DEFAULT '',
            supplier_name varchar(255) DEFAULT '',
            phone varchar(50) DEFAULT '',
            email varchar(100) DEFAULT '',
            supplier_price decimal(10,2) DEFAULT 0.00,
            retail_price decimal(10,2) DEFAULT 0.00,
            telegram varchar(100) DEFAULT '',
            whatsapp varchar(100) DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    public function add_admin_menu() {
        // FIX: Moved from top-level position 25 to Tools sub-menu to satisfy WordPress admin hierarchy guidelines
        add_management_page(
            'Supplier Info',
            'Supplier Info',
            'manage_options',
            $this->page_slug,
            array( $this, 'render_admin_page' )
        );
    }

    public function inject_custom_styles() {
        if ( isset( $_GET['page'] ) && $_GET['page'] === $this->page_slug ) {
            ?>
            <style>
                .supplier-pagination { margin-top: 20px; padding: 10px 0; display: flex; justify-content: flex-end; }
                .supplier-pagination .page-numbers { display: inline-block; padding: 6px 12px; margin: 0 4px; background: #fff; border: 1px solid #c3c4c7; color: #2271b1; text-decoration: none; border-radius: 4px; font-weight: 500; transition: all 0.2s ease-in-out; }
                .supplier-pagination .page-numbers:hover { background: #f0f6fa; border-color: #2271b1; color: #135e96; }
                .supplier-pagination .page-numbers.current { background: #2271b1; border-color: #2271b1; color: #fff; font-weight: bold; cursor: default; }
                .supplier-search-box { float: left; margin-bottom: 15px; }
                .supplier-search-box .clear-btn { display: inline-block; height: 30px; line-height: 28px; padding: 0 12px; background: #f6f7f7; border: 1px solid #d32d2e; color: #d32d2e; text-decoration: none; border-radius: 3px; vertical-align: middle; font-size: 13px; box-sizing: border-box; }
                .supplier-search-box .clear-btn:hover { background: #d32d2e; color: #fff; }
                .feature-list { list-style: none; padding: 0; margin: 10px 0 0 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 8px; }
                .feature-list li { margin: 0; font-size: 13px; display: flex; align-items: center; color: #2c3338; }
                .feature-list li::before { content: "⚡"; margin-right: 8px; }
            </style>
            <?php
        }
    }

    public function handle_db_actions() {
        global $wpdb;

        if ( ! isset( $_GET['page'] ) || $_GET['page'] !== $this->page_slug ) {
            return;
        }

        $base_url = admin_url( 'tools.php?page=' . $this->page_slug );

        // FIX: Sanitized $_GET['id'] safely inside an intval cast before nonce evaluation
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['id'] ) ) {
            $target_id = intval( $_GET['id'] );
            check_admin_referer( 'delete_supplier_' . $target_id );
            
            $wpdb->delete( $this->table_name, array( 'id' => $target_id ), array( '%d' ) );
            wp_safe_redirect( add_query_arg( 'msg', 'deleted', $base_url ) );
            exit;
        }

        if ( isset( $_POST['submit_supplier'] ) && check_admin_referer( 'supplier_form_action', 'supplier_nonce' ) ) {
            $data = array(
                'product_name'   => sanitize_text_field( $_POST['product_name'] ),
                'product_url'    => esc_url_raw( $_POST['product_url'] ),
                'supplier_name'  => sanitize_text_field( $_POST['supplier_name'] ),
                'phone'          => sanitize_text_field( $_POST['phone'] ),
                'email'          => sanitize_email( $_POST['email'] ),
                'supplier_price' => floatval( $_POST['supplier_price'] ),
                'retail_price'   => floatval( $_POST['retail_price'] ),
                'telegram'       => sanitize_text_field( $_POST['telegram'] ),
                'whatsapp'       => sanitize_text_field( $_POST['whatsapp'] ),
            );

            if ( ! empty( $_POST['entry_id'] ) ) {
                $entry_id = intval( $_POST['entry_id'] );
                $wpdb->update( $this->table_name, $data, array( 'id' => $entry_id ), array( '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%s' ), array( '%d' ) );
                wp_safe_redirect( add_query_arg( 'msg', 'updated', $base_url ) );
                exit;
            } else {
                $wpdb->insert( $this->table_name, $data, array( '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%s' ) );
                wp_safe_redirect( add_query_arg( 'msg', 'added', $base_url ) );
                exit;
            }
        }
    }

    public function render_admin_page() {
        global $wpdb;
        $message = '';
        $base_url = admin_url( 'tools.php?page=' . $this->page_slug );

        if ( isset( $_GET['msg'] ) ) {
            switch ( sanitize_key( $_GET['msg'] ) ) {
                case 'deleted':
                    $message = '<div class="updated"><p>' . esc_html__( 'Product successfully deleted.', 'ramerlabs-supplier-info-manager' ) . '</p></div>';
                    break;
                case 'added':
                    $message = '<div class="updated"><p>' . esc_html__( 'Product and Supplier info added successfully!', 'ramerlabs-supplier-info-manager' ) . '</p></div>';
                    break;
                case 'updated':
                    $message = '<div class="updated"><p>' . esc_html__( 'Product and Supplier info updated successfully!', 'ramerlabs-supplier-info-manager' ) . '</p></div>';
                    break;
            }
        }

        $edit_item = null;
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'edit' && isset( $_GET['id'] ) ) {
            $edit_item = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $this->table_name WHERE id = %d", intval( $_GET['id'] ) ) );
        }

        $search_term = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
        
        $per_page     = 10;
        $current_page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
        $offset       = ( $current_page - 1 ) * $per_page;

        if ( ! empty( $search_term ) ) {
            $like_query = '%' . $wpdb->esc_like( $search_term ) . '%';
            $count_query = $wpdb->prepare(
                "SELECT COUNT(id) FROM $this->table_name WHERE product_name LIKE %s OR supplier_name LIKE %s OR phone LIKE %s OR email LIKE %s OR telegram LIKE %s OR whatsapp LIKE %s",
                $like_query, $like_query, $like_query, $like_query, $like_query, $like_query
            );
            $total_items = $wpdb->get_var( $count_query );
            $total_pages = ceil( $total_items / $per_page );

            $data_query = $wpdb->prepare(
                "SELECT * FROM $this->table_name WHERE product_name LIKE %s OR supplier_name LIKE %s OR phone LIKE %s OR email LIKE %s OR telegram LIKE %s OR whatsapp LIKE %s ORDER BY id DESC LIMIT %d OFFSET %d",
                $like_query, $like_query, $like_query, $like_query, $like_query, $like_query, $per_page, $offset
            );
            $results = $wpdb->get_results( $data_query );
        } else {
            $total_items = $wpdb->get_var( "SELECT COUNT(id) FROM $this->table_name" );
            $total_pages = ceil( $total_items / $per_page );
            $results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $this->table_name ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ) );
        }
        ?>

        <div class="wrap">
            <h1 class="wp-heading-inline">RamerLabs Supplier Info Manager</h1>
            <?php if ( $edit_item ) : ?>
                <a href="<?php echo esc_url( $base_url ); ?>" class="page-title-action">Add New Product</a>
            <?php endif; ?>
            <hr class="wp-header-end">

            <?php echo wp_kses_post( $message ); ?>

            <div class="notice notice-info" style="margin: 20px 0; padding: 18px; border-left-color: #2271b1; background-color: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 4px;">
                <h2 style="margin: 0 0 6px 0; color: #1d2327; font-size: 18px; font-weight: 600;">📦 Supply-Chain Command Center</h2>
                <p style="font-size: 14px; margin: 0; color: #50575e; line-height: 1.4;">
                    Manage vendor items, trace wholesale costs, and instantly generate communication hooks straight from your active administration terminal.
                </p>
            </div>

            <div id="poststuff">
                <div id="post-body" class="metabox-holder columns-2">
                    
                    <div id="post-body-content">
                        <div class="supplier-search-box">
                            <form method="get" action="">
                                <input type="hidden" name="page" value="<?php echo esc_attr( $this->page_slug ); ?>" />
                                <input type="search" name="s" placeholder="Search suppliers..." value="<?php echo esc_attr( $search_term ); ?>" style="height: 30px; vertical-align: middle;" />
                                <input type="submit" class="button button-secondary" value="Search" style="height: 30px; vertical-align: middle;" />
                                <?php if ( ! empty( $search_term ) ) : ?>
                                    <a href="<?php echo esc_url( $base_url ); ?>" class="clear-btn">Clear Filter</a>
                                <?php endif; ?>
                            </form>
                        </div>
                        <div style="clear: both;"></div>

                        <div class="meta-box-sortables ui-sortable">
                            <div class="postbox">
                                <h2 class="hndle"><span>All Products</span></h2>
                                <div class="inside">
                                    <table class="wp-list-table widefat fixed striped table-view-list">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Supplier Name</th>
                                                <th>Contact Details</th>
                                                <th>Supplier Price</th>
                                                <th>Retail Price</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ( ! empty( $results ) ) : ?>
                                                <?php foreach ( $results as $row ) : ?>
                                                    <?php 
                                                    $edit_url = add_query_arg( array( 'action' => 'edit', 'id' => $row->id ), $base_url );
                                                    $delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'delete', 'id' => $row->id ), $base_url ), 'delete_supplier_' . $row->id );
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <strong><?php echo esc_html( $row->product_name ); ?></strong>
                                                            <?php if ( $row->product_url ) : ?>
                                                                <br><small><a href="<?php echo esc_url( $row->product_url ); ?>" target="_blank">View Link ↗</a></small>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo esc_html( $row->supplier_name ); ?></td>
                                                        <td>
                                                            <?php if ( ! empty( $row->phone ) ) echo '📞 ' . esc_html( $row->phone ) . '<br>'; ?>
                                                            <?php if ( ! empty( $row->email ) ) echo '✉️ ' . esc_html( $row->email ) . '<br>'; ?>
                                                            <?php if ( ! empty( $row->telegram ) ) echo '✈️ ' . esc_html( $row->telegram ) . '<br>'; ?>
                                                            <?php if ( ! empty( $row->whatsapp ) ) echo '💬 ' . esc_html( $row->whatsapp ); ?>
                                                        </td>
                                                        <td>$<?php echo esc_html( number_format( $row->supplier_price, 2 ) ); ?></td>
                                                        <td>$<?php echo esc_html( number_format( $row->retail_price, 2 ) ); ?></td>
                                                        <td>
                                                            <a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small">Edit</a>
                                                            <a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small" onclick="return confirm('Delete this supplier record?');" style="color: #b32d2e;">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php else : ?>
                                                <tr><td colspan="6">No entries match your query metrics.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>

                                    <?php if ( $total_pages > 1 ) : ?>
                                        <div class="supplier-pagination">
                                            <?php
                                            echo paginate_links( array(
                                                'base'      => add_query_arg( 'paged', '%#%' ),
                                                'format'    => '',
                                                'prev_text' => __( '&laquo; Previous' ),
                                                'next_text' => __( 'Next &raquo;' ),
                                                'total'     => $total_pages,
                                                'current'   => $current_page,
                                            ) );
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="postbox-container-1" class="postbox-container">
                        <div class="meta-box-sortables">
                            <div class="postbox">
                                <h2 class="hndle">
                                    <span><?php echo $edit_item ? 'Edit Entry' : 'Add New Record'; ?></span>
                                </h2>
                                <div class="inside">
                                    <form method="post" action="<?php echo esc_url( $base_url ); ?>">
                                        <?php wp_nonce_field( 'supplier_form_action', 'supplier_nonce' ); ?>
                                        
                                        <input type="hidden" name="entry_id" value="<?php echo $edit_item ? esc_attr( $edit_item->id ) : ''; ?>" />
                                        
                                        <p>
                                            <label for="product_name"><strong>Product Name *</strong></label><br>
                                            <input type="text" name="product_name" id="product_name" class="large-text" value="<?php echo $edit_item ? esc_attr( $edit_item->product_name ) : ''; ?>" required />
                                        </p>
                                        <p>
                                            <label for="product_url"><strong>Product URL</strong></label><br>
                                            <input type="url" name="product_url" id="product_url" class="large-text" value="<?php echo $edit_item ? esc_url( $edit_item->product_url ) : ''; ?>" />
                                        </p>
                                        <p>
                                            <label for="supplier_name"><strong>Supplier Name</strong></label><br>
                                            <input type="text" name="supplier_name" id="supplier_name" class="large-text" value="<?php echo $edit_item ? esc_attr( $edit_item->supplier_name ) : ''; ?>" />
                                        </p>
                                        <p>
                                            <label for="supplier_price"><strong>Supplier Price ($)</strong></label><br>
                                            <input type="number" step="0.01" name="supplier_price" id="supplier_price" class="regular-text" value="<?php echo $edit_item ? esc_attr( $edit_item->supplier_price ) : '0.00'; ?>" />
                                        </p>
                                        <p>
                                            <label for="retail_price"><strong>Retail Price ($)</strong></label><br>
                                            <input type="number" step="0.01" name="retail_price" id="retail_price" class="regular-text" value="<?php echo $edit_item ? esc_attr( $edit_item->retail_price ) : '0.00'; ?>" />
                                        </p>
                                        <hr>
                                        <h3>Contact Info</h3>
                                        <p>
                                            <label for="phone"><strong>Phone</strong></label><br>
                                            <input type="text" name="phone" id="phone" class="large-text" value="<?php echo $edit_item ? esc_attr( $edit_item->phone ) : ''; ?>" />
                                        </p>
                                        <p>
                                            <label for="email"><strong>Email</strong></label><br>
                                            <input type="email" name="email" id="email" class="large-text" value="<?php echo $edit_item ? esc_attr( $edit_item->email ) : ''; ?>" />
                                        </p>
                                        <p>
                                            <label for="telegram"><strong>Telegram Handle</strong></label><br>
                                            <input type="text" name="telegram" id="telegram" class="large-text" placeholder="@username" value="<?php echo $edit_item ? esc_attr( $edit_item->telegram ) : ''; ?>" />
                                        </p>
                                        <p>
                                            <label for="whatsapp"><strong>WhatsApp Number</strong></label><br>
                                            <input type="text" name="whatsapp" id="whatsapp" class="large-text" value="<?php echo $edit_item ? esc_attr( $edit_item->whatsapp ) : ''; ?>" />
                                        </p>
                                        
                                        <p class="submit">
                                            <input type="submit" name="submit_supplier" id="submit" class="button button-primary button-large" value="<?php echo $edit_item ? 'Update Entry' : 'Save Entry'; ?>">
                                            <?php if ( $edit_item ) : ?>
                                                <a href="<?php echo esc_url( $base_url ); ?>" class="button button-secondary" style="margin-left: 5px;">Cancel</a>
                                            <?php endif; ?>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php
    }
}

new RamerLabs_Supplier_Manager();